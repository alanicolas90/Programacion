package modelo;

public enum ValoresCelda {
    X,O
}
