package constantes;

public class Constantes {
    public static final String SEPARATION = "-----------------------------------------------------------------------";
    public static final String FELICIDADES = "¡¡FELICIDADES!!";
}
