package main;

import java.util.Scanner;

public class Repetitivas19 {
    public void media(Scanner sc) {
        System.out.println("Ya lo estas viendo");
    }
}
