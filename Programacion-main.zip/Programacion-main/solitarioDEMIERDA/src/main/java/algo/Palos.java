package algo;

public enum Palos {
    ESPADAS, OROS, BASTOS, COPAS
}
