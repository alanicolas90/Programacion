package dao;

public class DaoTableroVisible {
}
