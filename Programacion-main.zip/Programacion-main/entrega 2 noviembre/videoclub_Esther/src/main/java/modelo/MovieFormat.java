package modelo;

public enum MovieFormat {

  DVD,VIDEO;
}
